#!/bin/bash

DB_USER=
DB_PASS=
DB_SID=
# 늘리면 더 많은 세션에서 수행함
SCALE_FACTOR=1

# 입력 검증 (필수 환경 변수 체크)
if [[ -z "$DB_USER" || -z "$DB_PASS" || -z "$DB_SID" ]]; then
    echo "사용법: 환경 변수를 설정해야 합니다."
    echo "예제:"
    echo '  export DB_USER="your_user"'
    echo '  export DB_PASS="your_password"'
    echo '  export DB_SID="your_db"'
    exit 1
fi

# 실행할 SQL 스크립트 목록
SQL_SCRIPTS=(
    "load_insert_delete.sql"
    "load_temp_tablespace.sql"
    "load_undo_tablespace.sql"
    "load_lock_test.sql"
)

# 로그 디렉토리 설정
LOG_DIR="./logs"
mkdir -p $LOG_DIR

# 부모 프로세스 종료 시 자식 프로세스도 종료하도록 트랩 설정
trap 'echo "프로세스 종료 중..."; pkill -P $$; exit 0' SIGTERM SIGINT

# 초기 테이블 생성 스크립트 실행
echo "초기 테이블을 생성합니다..."
tbsql $DB_USER/$DB_PASS@$DB_SID @init.sql

# 백그라운드에서 SQL 스크립트 실행
echo "Tibero 부하 테스트를 시작합니다..."
for ((i=1; i<=SCALE_FACTOR; i++)); do
    for script in "${SQL_SCRIPTS[@]}"; do
        tbsql $DB_USER/$DB_PASS@$DB_SID @"$script" > "$LOG_DIR/session_${i}_$(basename $script .sql).log" 2>&1 &
        echo "Tibero 부하 테스트를 시작합니다... ($script) $i"
    done
done

# 현재 프로세스가 종료될 때까지 대기
wait
