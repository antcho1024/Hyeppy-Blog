DECLARE
v_id NUMBER;
BEGIN
FOR i IN 1..1000 LOOP
        INSERT INTO test_table (id, data) VALUES (i, 'Performance Test Data');
DELETE FROM test_table WHERE id = i;
COMMIT;
END LOOP;
END;
/
EXIT;