BEGIN
FOR i IN 1..1000 LOOP
UPDATE test_table SET data = data || ' Update Test' WHERE id = MOD(i, 100);
-- 언두 테이블스페이스를 사용하도록 롤백 없이 연속 실행
END LOOP;
END;
/
EXIT;