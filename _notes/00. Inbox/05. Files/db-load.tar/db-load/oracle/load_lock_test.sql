-- 세션 1: 락을 거는 트랜잭션
BEGIN
UPDATE test_table SET data = 'LOCK TEST' WHERE id = 1;
DBMS_LOCK.SLEEP(10);  -- 10초 동안 락 유지
END;
/

-- 세션 2: 락에 걸리는 트랜잭션 (이 스크립트는 별도 세션에서 실행)
BEGIN
UPDATE test_table SET data = 'DEADLOCK TEST' WHERE id = 1;
END;
/
EXIT;
