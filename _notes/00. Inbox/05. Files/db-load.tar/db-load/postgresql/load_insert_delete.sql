DO $$ 
DECLARE i INT;
BEGIN
    FOR i IN 1..1000 LOOP
        INSERT INTO test_table (data) VALUES ('Performance Test Data');
        DELETE FROM test_table WHERE id = (SELECT min(id) FROM test_table);
        COMMIT;
    END LOOP;
END $$;

