#!/bin/bash

# PostgreSQL 접속 정보
PG_USER=
PG_PASS=
PG_DB=
PG_HOST=
PG_PORT=

# 환경 변수 확인
if [[ -z "$PG_USER" || -z "$PG_PASS" || -z "$PG_DB" || -z "$PG_HOST" || -z "$PG_PORT" ]]; then
    echo "사용법: 환경 변수를 설정해야 합니다."
    echo "예제:"
    echo '  export PG_USER="your_user"'
    echo '  export PG_PASS="your_password"'
    echo '  export PG_DB="your_db"'
    echo '  export PG_HOST="your_pg_host"'
    echo '  export PG_DB="your_pg_port"'
    exit 1
fi

# 실행할 SQL 스크립트 목록
SQL_SCRIPTS=(
    "load_insert_delete.sql"
    "load_temp_tablespace.sql"
    "load_undo_tablespace.sql"
    "load_lock_test.sql"
)

# 실행할 세션 수
SESSION_COUNT=6

# 로그 디렉토리 설정
LOG_DIR="./logs"
mkdir -p $LOG_DIR

# 부모 프로세스 종료 시 모든 자식 프로세스도 종료하도록 트랩 설정
trap 'echo "프로세스 종료 중..."; pkill -P $$; exit 0' SIGTERM SIGINT

# 초기 테이블 생성 스크립트 실행
echo "초기 테이블을 생성합니다..."
PGPASSWORD=$PG_PASS psql -U $PG_USER -h $PG_HOST -p $PG_PORT -d $PG_DB -f init.sql

# 백그라운드에서 SQL 스크립트 실행
echo "PostgreSQL 부하 테스트를 시작합니다..."
for ((i=1; i<=SESSION_COUNT; i++)); do
    for script in "${SQL_SCRIPTS[@]}"; do
        PGPASSWORD=$PG_PASS psql -U $PG_USER -h $PG_HOST -p $PG_PORT -d $PG_DB -f "$script" > "$LOG_DIR/session_${i}_$(basename $script .sql).log" 2>&1 &
    done
done

# 현재 프로세스가 종료될 때까지 대기
wait

