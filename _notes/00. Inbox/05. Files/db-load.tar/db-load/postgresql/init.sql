-- 기존 테이블 삭제 (존재할 경우)
DROP TABLE IF EXISTS test_table CASCADE;
DROP TABLE IF EXISTS temp_table CASCADE;
DROP TABLE IF EXISTS undo_test_table CASCADE;
DROP TABLE IF EXISTS lock_test_table CASCADE;

CREATE TABLE test_table (
    id SERIAL PRIMARY KEY,
    data TEXT
);

-- PostgreSQL에서는 세션 종료 시 자동 삭제됨
CREATE TEMP TABLE temp_table (
    id SERIAL,
    data TEXT
) ON COMMIT PRESERVE ROWS;

CREATE TABLE undo_test_table (
    id SERIAL PRIMARY KEY,
    data TEXT
);

CREATE TABLE lock_test_table (
    id SERIAL PRIMARY KEY,
    data TEXT
);

INSERT INTO test_table (data)
SELECT 'Initial Data ' || generate_series(1, 100);

INSERT INTO undo_test_table (data)
SELECT 'Undo Test Data ' || generate_series(1, 100);

INSERT INTO lock_test_table (data)
VALUES ('Lock Test Initial Data');

COMMIT;

