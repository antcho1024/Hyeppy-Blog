DO $$ 
DECLARE v_temp TEXT;
BEGIN
    FOR i IN 1..500 LOOP
        SELECT repeat('X', 4000) INTO v_temp;
    END LOOP;
END $$;

