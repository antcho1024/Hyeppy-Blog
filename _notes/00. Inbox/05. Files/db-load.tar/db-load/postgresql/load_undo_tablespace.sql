DO $$ 
DECLARE i INT;
BEGIN
    FOR i IN 1..1000 LOOP
        UPDATE undo_test_table 
        SET data = data || ' Update Test' 
        WHERE id = (i % 100 + 1);
    END LOOP;
END $$;

