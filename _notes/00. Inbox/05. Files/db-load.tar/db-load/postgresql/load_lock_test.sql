-- 세션 1: 특정 행을 업데이트하여 락 유지
BEGIN;
UPDATE lock_test_table SET data = 'LOCK TEST' WHERE id = 1;
SELECT pg_sleep(10); -- 10초 동안 락 유지
ROLLBACK;

-- 세션 2: 락에 걸리는 트랜잭션
UPDATE lock_test_table SET data = 'DEADLOCK TEST' WHERE id = 1;

